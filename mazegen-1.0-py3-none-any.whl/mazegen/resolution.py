"""
Maze solving and export functionality built on top of maze generation.

Defines :class:`SolveMaze`, which extends :class:`MazeGenenrator` with
a breadth-first search solver to find the shortest path between the
maze's entry and exit points, and utilities to export the maze and
its solution to a text file.
"""

